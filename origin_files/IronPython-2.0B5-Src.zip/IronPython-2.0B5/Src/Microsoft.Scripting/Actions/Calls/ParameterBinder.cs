/* ****************************************************************************
 *
 * Copyright (c) Microsoft Corporation. 
 *
 * This source code is subject to terms and conditions of the Microsoft Public License. A 
 * copy of the license can be found in the License.html file at the root of this distribution. If 
 * you cannot locate the  Microsoft Public License, please send an email to 
 * dlr@microsoft.com. By using this source code in any fashion, you are agreeing to be bound 
 * by the terms of the Microsoft Public License.
 *
 * You must not remove this notice, or any other, from this software.
 *
 *
 * ***************************************************************************/

using System; using Microsoft;
using System.Collections.Generic;
using Microsoft.Linq.Expressions;
using Microsoft.Scripting.Utils;
using Microsoft.Scripting.Actions;
using System.Reflection;

namespace Microsoft.Scripting.Actions.Calls {
    /// <summary>
    /// Helper class for emitting calls via the MethodBinder.
    /// </summary>
    public class ParameterBinder {
        private readonly ActionBinder _actionBinder;
        private List<VariableExpression> _temps;

        public ParameterBinder(ActionBinder actionBinder) {
            Assert.NotNull(actionBinder);

            _actionBinder = actionBinder;
        }

        public ActionBinder Binder {
            get { return _actionBinder; }
        }

        internal List<VariableExpression> Temps {
            get { return _temps; }
        }

        internal VariableExpression GetTemporary(Type type, string name) {
            Assert.NotNull(type, name);

            if (_temps == null) {
                _temps = new List<VariableExpression>();
            }

            VariableExpression res = Expression.Variable(type, name);
            _temps.Add(res);
            return res;
        }

        public virtual Expression ConvertExpression(Expression expr, ParameterInfo info, Type toType) {
            Assert.NotNull(expr, toType);

            return _actionBinder.ConvertExpression(expr, toType, ConversionResultKind.ExplicitCast, null);
        }

        public virtual Expression GetDynamicConversion(Expression value, Type type) {
            return Expression.Dynamic(OldConvertToAction.Make(_actionBinder, type), type, value);
        }
    }

}
