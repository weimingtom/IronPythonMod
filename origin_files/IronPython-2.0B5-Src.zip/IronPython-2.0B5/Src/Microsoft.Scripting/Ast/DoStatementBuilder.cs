/* ****************************************************************************
 *
 * Copyright (c) Microsoft Corporation. 
 *
 * This source code is subject to terms and conditions of the Microsoft Public License. A 
 * copy of the license can be found in the License.html file at the root of this distribution. If 
 * you cannot locate the  Microsoft Public License, please send an email to 
 * dlr@microsoft.com. By using this source code in any fashion, you are agreeing to be bound 
 * by the terms of the Microsoft Public License.
 *
 * You must not remove this notice, or any other, from this software.
 *
 *
 * ***************************************************************************/
using System; using Microsoft;
using Microsoft.Linq.Expressions;
using Microsoft.Scripting;
using Microsoft.Scripting.Utils;

namespace Microsoft.Scripting.Ast {
    public sealed class DoStatementBuilder {
        private readonly Expression _body;
        private readonly Annotations _annotations;
        private readonly LabelTarget _label;

        internal DoStatementBuilder(Annotations annotations, LabelTarget label, Expression body) {
            ContractUtils.RequiresNotNull(body, "body");

            _body = body;
            _annotations = annotations;
            _label = label;
        }

        public DoStatement While(Expression condition) {
            return Expression.DoWhile(_body, condition, _label, _annotations);
        }
    }

    public partial class Utils {
        public static DoStatementBuilder Do(params Expression[] body) {
            ContractUtils.RequiresNotNullItems(body, "body");
            return new DoStatementBuilder(Annotations.Empty, null, Expression.Block(body));
        }

        public static DoStatementBuilder Do(LabelTarget label, params Expression[] body) {
            ContractUtils.RequiresNotNullItems(body, "body");
            return new DoStatementBuilder(Annotations.Empty, label, Expression.Block(body));
        }

        public static DoStatementBuilder Do(LabelTarget label, Annotations annotations, params Expression[] body) {
            return new DoStatementBuilder(annotations, label, Expression.Block(body));
        }

        public static DoStatementBuilder Do(SourceSpan statementSpan, SourceLocation location, params Expression[] body) {
            return Do(null, Expression.Annotate(statementSpan, location), body);
        }

        public static DoStatementBuilder Do(SourceSpan statementSpan, SourceLocation location, LabelTarget label, params Expression[] body) {
            return Do(label, Expression.Annotate(statementSpan, location), body);
        }
    }
}
